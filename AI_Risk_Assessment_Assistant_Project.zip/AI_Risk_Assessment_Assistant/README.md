# AI Risk Assessment Assistant for a Small Business

## Overview
A Streamlit web app that lets a small business record risks, score likelihood and impact, see risk levels, review practical mitigation suggestions, and export a CSV risk register.

## Features
- Business profile inputs
- Risk categories: Cybersecurity, Financial, Operational, Compliance, People
- Transparent risk score: likelihood × impact (1–25)
- Risk levels: Low, Medium, High, Critical
- Category-based mitigation suggestions
- Dashboard summary and CSV export

## Requirements
- Python 3.10 or later
- Internet connection for initial package installation

## Run locally
1. Extract this project folder.
2. Open a terminal in the folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the app:

   ```bash
   streamlit run app.py
   ```

6. Open the local URL printed in the terminal, usually `http://localhost:8501`.

## Risk scoring model
Score = Likelihood × Impact.

| Score | Level |
|---:|---|
| 1–5 | Low |
| 6–11 | Medium |
| 12–19 | High |
| 20–25 | Critical |

Likelihood and impact are each rated from 1 to 5. These thresholds are an illustrative project model and should be calibrated for a real organization.

## Limitations
- Recommendations are predefined and rule-based; this version does not call an external generative AI model.
- Data stays in Streamlit session state and is not stored permanently.
- Scores depend on user judgment and may be incomplete or biased.
- This tool is decision support, not professional legal, financial, compliance, or cybersecurity advice.
- Do not enter passwords, payment card details, or sensitive personal data.

## Suggested future enhancements
- Add SQLite storage with authentication and access controls.
- Add an optional LLM API for tailored explanations, with human review.
- Add charts, risk trend history, and mitigation deadlines.
- Add role-based access and audit logs.
- Map controls to a chosen framework such as NIST CSF or ISO 27001 where appropriate.
- Add automated reminders for overdue mitigation tasks.

## Academic project outline
1. Introduction and problem statement
2. Objectives and scope
3. System requirements
4. Architecture and workflow
5. Risk scoring methodology
6. Implementation
7. Test cases and results
8. Limitations and future scope
9. Conclusion
